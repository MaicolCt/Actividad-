const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

io.on('connection', (socket) => {
    console.log('Un usuario se ha conectado');
    let isTyping = false;

    socket.on('user joined', (username) => {
        console.log(`${username} se ha unido al chat`);
        io.emit('chat message', {
            username: 'Sistema',
            message: `${username} se ha unido al chat`,
            timestamp: new Date().toLocaleTimeString()
        });
    });

    socket.on('typing', (username) => {
        if (!isTyping) {
            isTyping = true;
            socket.broadcast.emit('user typing', username);
        }
    });

    socket.on('stop typing', (username) => {
        isTyping = false;
        socket.broadcast.emit('user stop typing', username);
    });

    socket.on('chat message', (messageData) => {
        io.emit('chat message', messageData);
    });

    socket.on('disconnect', () => {
        console.log('Un usuario se ha desconectado');
    });
});

const PORT = process.env.PORT || 3001;
http.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});